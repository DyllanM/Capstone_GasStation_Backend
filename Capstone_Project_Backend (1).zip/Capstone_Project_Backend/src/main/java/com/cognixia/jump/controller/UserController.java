package com.cognixia.jump.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognixia.jump.model.Employee;
import com.cognixia.jump.model.User;
import com.cognixia.jump.repository.PurchaseRepository;
import com.cognixia.jump.repository.UserRepository;

@RequestMapping("/api")
@RestController

public class UserController {
	
	@Autowired
	UserRepository repo;
	
	@GetMapping("/users/{id}")
	public User getUser(@PathVariable long id) {

		Optional<User> found = repo.findById(id);

		if (found.isPresent()) {
			
			return found.get();
		} else {
			return new User();
		}
	}
	// set up an api, i have the used id, can you return me the employee object whose used id is this,
	
	@GetMapping("/{id}")
	public Employee getEmployee(@PathVariable long id) {

		Optional<User> found = repo.findById(id);

		if (found.isPresent()) {
			
			
			 return found.get().getEmployee();
		} else {
			return new Employee();
		}
	}
		
	}


