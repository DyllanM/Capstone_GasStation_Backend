package com.cognixia.jump.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.cognixia.jump.model.AuthenticationRequest;
import com.cognixia.jump.model.AuthenticationResponse;
import com.cognixia.jump.model.Employee;
import com.cognixia.jump.model.User;
import com.cognixia.jump.model.User.Role;
import com.cognixia.jump.repository.EmployeeRepository;
import com.cognixia.jump.repository.UserRepository;
import com.cognixia.jump.service.MyUserDetailsService;
import com.cognixia.jump.util.JwtUtil;

@RequestMapping("/api")
@RestController
@CrossOrigin(origins="*", allowedHeaders="*")
public class LoginController {
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private MyUserDetailsService userDetailsService;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired 
	private EmployeeRepository empRepo;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	
	@PostMapping("/employees/add")
	public ResponseEntity<?> createNewUser(@RequestBody Employee employee)
	
	{
		
		Optional<User> isAlreadyRegistered = userRepo.findByUsername(employee.getUser().getUsername());
		
		if (isAlreadyRegistered.isPresent())
		{
			return ResponseEntity.status(HttpStatus.CONFLICT).body(employee.getUser().getUsername() + " already exists! ");
		}
		
		
		
		String submittedPassword = employee.getUser().getPassword();
		String encodedPassword = passwordEncoder.encode(submittedPassword);
		employee.getUser().setPassword(encodedPassword);
		
		
		
		employee.setId(-1L);
		Employee createdEmp = empRepo.save(employee);
	
	return ResponseEntity.status(201).body(createdEmp);
	
	}
	
	@PostMapping("/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest request) throws Exception {
		
		try {
			
			authenticationManager.authenticate(
						new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
					);
			
		} catch (Exception e) {
			
			throw new Exception("Incorrect username or password", e);
			
		}
		
		final UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());
		
		final String JWT = jwtUtil.generateTokens(userDetails);
		
		Optional<User> user = userRepo.findByUsername(request.getUsername());
		
		// return ResponseEntity.ok(new AuthenticationResponse(JWT));
		
		return ResponseEntity.status(201).body(user.get().getId());
		
	}
	
}
