package com.cognixia.jump.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Employee implements Serializable{

	private static final long serialVersionUID = -588539683404124554L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(nullable = false)
	private String name;
	
	@Column(nullable = false)
	private String email;
	
	@Column(unique = true)
	private String phoneNumber;
	
	@JsonIgnore
	@OneToMany(mappedBy="employee", cascade=CascadeType.ALL)
	private List<Purchase> purchases;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(unique = true)
	private User user;
	
	public Employee()
	{
		this(-1L, "N/A", "N/A", "000000000", new ArrayList<Purchase>());
	}

	public Employee(Long id, String name, String email, String phoneNumber, List<Purchase> purchases) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.purchases = purchases;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	
	
	public List<Purchase> getPurchases() {
		
		return purchases;
	}
	
	public void setPurchases(List<Purchase> purchases) {
		
		for(int pur = 0; pur < purchases.size(); pur++) {
			addPurchase(purchases.get(pur));
		}
	}
	
	public void addPurchase(Purchase purchase) {
		purchase.setEmployee(this);
		purchases.add(purchase);
	}
	
	public Purchase getPurchase(Long id) {
		
		for(int idx = 0; idx < purchases.size(); idx++) {
			
			if(purchases.get(idx).getId() == id) {
				
				return purchases.get(idx);
			}
		}
		
		return new Purchase();
	}
	
	public void updatePurchase(Purchase purchase) {
		
		Purchase toUpdate = getPurchase(purchase.getId());
		
		if(toUpdate.getId() != -1) {
			toUpdate.setCost(purchase.getCost());
			toUpdate.setPurchaseDate(purchase.getPurchaseDate());
		}
		
	}



	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", email=" + email + ", phoneNumber=" + phoneNumber + "]";
	}
	
	
	

}
